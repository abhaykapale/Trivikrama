import type { RedisClient } from "../../../database/redis/client.js";
import type { IUnitOfWork } from "../../../database/transactions/transaction.types.js";
import { CreateRuleUseCase } from "../application/create-rule.use-case.js";
import { PostgresRuleCreationUnitOfWork } from "../infrastructure/postgres-rule-creation-unit-of-work.js";
import { RedisRuleReloadPublisher } from "../infrastructure/redis-rule-reload.publisher.js";

export interface RuleCommandDependencies {
  readonly createRuleUseCase: CreateRuleUseCase;
}

export function createRuleCommandDependencies(
  unitOfWork: IUnitOfWork,
  redis: RedisClient,
): RuleCommandDependencies {
  return {
    createRuleUseCase: new CreateRuleUseCase({
      unitOfWork: new PostgresRuleCreationUnitOfWork(unitOfWork),
      reloadSignals: new RedisRuleReloadPublisher(redis),
    }),
  };
}
