import type { IAuditRepository } from "../../../database/repositories/audit/audit.repository.js";
import type { IRuleRepository, RuleRecord, RuleSeverity, RuleType } from "../../../database/repositories/rules/rule.repository.js";
import type { AuthRole } from "../../auth/domain/index.js";

export const MAX_SIGMA_RULE_SOURCE_BYTES = 50 * 1_024;

export interface RuleCommandActor {
  readonly id: string;
  readonly username: string;
  readonly role: AuthRole;
  readonly ipAddress: string | null;
}

export interface CreateRuleCommand {
  readonly orgId: string;
  readonly yamlContent: string;
  readonly actor: RuleCommandActor;
}

export interface ValidatedSigmaRule {
  readonly sigmaId: string;
  readonly name: string;
  readonly description: string;
  readonly status: "active";
  readonly type: Exclude<RuleType, "sequence">;
  readonly severity: RuleSeverity;
  readonly weight: number;
  readonly priority: number;
  readonly classUid: number;
  readonly categoryUid: number | null;
  readonly tags: readonly string[];
  readonly falsePositives: readonly string[];
  readonly references: readonly string[];
  readonly compiledHash: string;
  readonly yamlContent: string;
}

export interface CreateRuleResult {
  readonly id: string;
  readonly sigmaId: string;
  readonly name: string;
  readonly status: "active";
  readonly type: Exclude<RuleType, "sequence">;
  readonly severity: RuleSeverity;
  readonly version: number;
  readonly createdAt: Date;
  readonly reloadSignaled: boolean;
}

export interface RuleCreationTransaction {
  readonly rules: Pick<IRuleRepository, "create" | "findByName" | "findBySigmaId">;
  readonly audit: Pick<IAuditRepository, "create">;
}

export interface RuleCreationUnitOfWork {
  execute<TResult>(
    operation: (transaction: RuleCreationTransaction) => Promise<TResult>,
  ): Promise<TResult>;
}

export interface RuleReloadSignal {
  readonly organizationId: string;
  readonly ruleId: string;
  readonly operation: "created";
}

export interface RuleReloadSignalPublisher {
  publish(signal: RuleReloadSignal): Promise<boolean>;
}

export class DuplicateSigmaRuleError extends Error {
  public readonly code: "RULE_ID_EXISTS" | "RULE_NAME_EXISTS";

  public constructor(
    public readonly duplicateField: "sigmaId" | "name",
    public readonly duplicateValue: string,
  ) {
    super(
      duplicateField === "sigmaId"
        ? `Rule with Sigma ID ${duplicateValue} already exists.`
        : `Rule with name ${duplicateValue} already exists.`,
    );
    this.name = "DuplicateSigmaRuleError";
    this.code = duplicateField === "sigmaId" ? "RULE_ID_EXISTS" : "RULE_NAME_EXISTS";
  }
}

export class RuleRepositoryUniqueConflictError extends Error {
  public constructor(public readonly constraint: string | null) {
    super("A tenant-unique rule identity already exists.");
    this.name = "RuleRepositoryUniqueConflictError";
  }
}

export type CreatedRuleRecord = Pick<
  RuleRecord,
  "id" | "name" | "status" | "type" | "severity" | "version" | "createdAt"
>;
