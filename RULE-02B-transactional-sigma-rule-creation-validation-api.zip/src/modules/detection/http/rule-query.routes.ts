import { Router, type NextFunction, type Request, type Response } from "express";
import { ZodError } from "zod";

import {
  authenticateRequest,
  requireAuthenticatedPrincipal,
  requirePermission,
  type AuthenticateRequestDependencies,
} from "../../auth/http/index.js";
import { sendError } from "../../auth/http/auth-http.errors.js";
import type { GetRuleDetailUseCase } from "../application/get-rule-detail.use-case.js";
import type { ListRulesUseCase } from "../application/list-rules.use-case.js";
import type { CreateRuleUseCase } from "../application/create-rule.use-case.js";
import { DuplicateSigmaRuleError } from "../domain/rule-command.contracts.js";
import { RuleValidationError } from "../domain/rule-validation.error.js";
import {
  createRuleBodySchema,
  listRulesQuerySchema,
  ruleIdParamsSchema,
} from "./rule-query.schemas.js";

export interface CreateRuleQueryRouterDependencies {
  readonly authentication: AuthenticateRequestDependencies;
  readonly listRulesUseCase: Pick<ListRulesUseCase, "execute">;
  readonly getRuleDetailUseCase: Pick<GetRuleDetailUseCase, "execute">;
  readonly createRuleUseCase?: Pick<CreateRuleUseCase, "execute">;
}

export function createRuleQueryRouter(
  dependencies: CreateRuleQueryRouterDependencies,
): Router {
  const router = Router();
  const security = [
    authenticateRequest(dependencies.authentication),
    requirePermission("rules.view"),
  ] as const;

  router.get("/", ...security, async (request, response, next) => {
    await handleList(request, response, next, dependencies);
  });
  router.post(
    "/",
    authenticateRequest(dependencies.authentication),
    requirePermission("rules.create"),
    async (request, response, next) => {
      await handleCreate(request, response, next, dependencies);
    },
  );
  router.get("/:id", ...security, async (request, response, next) => {
    await handleDetail(request, response, next, dependencies);
  });

  return router;
}

async function handleCreate(
  request: Request,
  response: Response,
  next: NextFunction,
  dependencies: CreateRuleQueryRouterDependencies,
): Promise<void> {
  try {
    if (dependencies.createRuleUseCase === undefined) {
      throw new Error("Rule-creation dependency is not configured.");
    }
    const body = createRuleBodySchema.parse(request.body);
    const principal = requireAuthenticatedPrincipal(request);
    const created = await dependencies.createRuleUseCase.execute({
      orgId: principal.orgId,
      yamlContent: body.yamlContent,
      actor: {
        id: principal.userId,
        username: principal.username,
        role: principal.role,
        ipAddress: request.ip ?? null,
      },
    });
    response.status(201).json(created);
  } catch (error: unknown) {
    if (error instanceof ZodError) {
      sendRuleValidationResponse(response, "Invalid rule creation request.", error);
      return;
    }
    if (error instanceof RuleValidationError) {
      sendError(response, 400, error.code, "Rule validation failed.", {
        errors: error.issues.map((issue) => `${issue.path}: ${issue.message}`),
        issues: error.issues,
      });
      return;
    }
    if (error instanceof DuplicateSigmaRuleError) {
      sendError(response, 409, error.code, error.message, {
        field: error.duplicateField,
        value: error.duplicateValue,
      });
      return;
    }
    next(error);
  }
}

async function handleList(
  request: Request,
  response: Response,
  next: NextFunction,
  dependencies: CreateRuleQueryRouterDependencies,
): Promise<void> {
  try {
    const query = listRulesQuerySchema.parse(request.query);
    const principal = requireAuthenticatedPrincipal(request);
    const result = await dependencies.listRulesUseCase.execute({
      orgId: principal.orgId,
      ...query,
    });
    response.status(200).json(result);
  } catch (error: unknown) {
    handleRuleQueryError(error, response, next, "Invalid rule listing parameters.");
  }
}

async function handleDetail(
  request: Request,
  response: Response,
  next: NextFunction,
  dependencies: CreateRuleQueryRouterDependencies,
): Promise<void> {
  try {
    const { id } = ruleIdParamsSchema.parse(request.params);
    const principal = requireAuthenticatedPrincipal(request);
    const rule = await dependencies.getRuleDetailUseCase.execute({
      orgId: principal.orgId,
      ruleId: id,
    });
    if (rule === null) {
      sendError(response, 404, "RESOURCE_NOT_FOUND", `Rule with ID ${id} not found.`);
      return;
    }
    response.status(200).json(rule);
  } catch (error: unknown) {
    handleRuleQueryError(error, response, next, "Invalid rule ID.");
  }
}

function handleRuleQueryError(
  error: unknown,
  response: Response,
  next: NextFunction,
  message: string,
): void {
  if (error instanceof ZodError) {
    sendRuleValidationResponse(response, message, error);
    return;
  }
  next(error);
}

function sendRuleValidationResponse(
  response: Response,
  message: string,
  error: ZodError,
): void {
  sendError(response, 400, "VALIDATION_ERROR", message, {
    issues: error.issues.map((issue) => ({
      path: issue.path.join("."),
      message: issue.message,
    })),
  });
}
