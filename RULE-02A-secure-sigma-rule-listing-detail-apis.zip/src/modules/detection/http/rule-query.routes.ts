import { Router, type NextFunction, type Request, type Response } from "express";
import { ZodError } from "zod";

import {
  authenticateRequest,
  requireAuthenticatedPrincipal,
  requirePermission,
  type AuthenticateRequestDependencies,
} from "../../auth/http/index.js";
import { sendError } from "../../auth/http/auth-http.errors.js";
import type { GetRuleDetailUseCase } from "../application/get-rule-detail.use-case.js";
import type { ListRulesUseCase } from "../application/list-rules.use-case.js";
import { listRulesQuerySchema, ruleIdParamsSchema } from "./rule-query.schemas.js";

export interface CreateRuleQueryRouterDependencies {
  readonly authentication: AuthenticateRequestDependencies;
  readonly listRulesUseCase: Pick<ListRulesUseCase, "execute">;
  readonly getRuleDetailUseCase: Pick<GetRuleDetailUseCase, "execute">;
}

export function createRuleQueryRouter(
  dependencies: CreateRuleQueryRouterDependencies,
): Router {
  const router = Router();
  const security = [
    authenticateRequest(dependencies.authentication),
    requirePermission("rules.view"),
  ] as const;

  router.get("/", ...security, async (request, response, next) => {
    await handleList(request, response, next, dependencies);
  });
  router.get("/:id", ...security, async (request, response, next) => {
    await handleDetail(request, response, next, dependencies);
  });

  return router;
}

async function handleList(
  request: Request,
  response: Response,
  next: NextFunction,
  dependencies: CreateRuleQueryRouterDependencies,
): Promise<void> {
  try {
    const query = listRulesQuerySchema.parse(request.query);
    const principal = requireAuthenticatedPrincipal(request);
    const result = await dependencies.listRulesUseCase.execute({
      orgId: principal.orgId,
      ...query,
    });
    response.status(200).json(result);
  } catch (error: unknown) {
    handleRuleQueryError(error, response, next, "Invalid rule listing parameters.");
  }
}

async function handleDetail(
  request: Request,
  response: Response,
  next: NextFunction,
  dependencies: CreateRuleQueryRouterDependencies,
): Promise<void> {
  try {
    const { id } = ruleIdParamsSchema.parse(request.params);
    const principal = requireAuthenticatedPrincipal(request);
    const rule = await dependencies.getRuleDetailUseCase.execute({
      orgId: principal.orgId,
      ruleId: id,
    });
    if (rule === null) {
      sendError(response, 404, "RESOURCE_NOT_FOUND", `Rule with ID ${id} not found.`);
      return;
    }
    response.status(200).json(rule);
  } catch (error: unknown) {
    handleRuleQueryError(error, response, next, "Invalid rule ID.");
  }
}

function handleRuleQueryError(
  error: unknown,
  response: Response,
  next: NextFunction,
  message: string,
): void {
  if (error instanceof ZodError) {
    sendError(response, 400, "VALIDATION_ERROR", message, {
      issues: error.issues.map((issue) => ({
        path: issue.path.join("."),
        message: issue.message,
      })),
    });
    return;
  }
  next(error);
}
