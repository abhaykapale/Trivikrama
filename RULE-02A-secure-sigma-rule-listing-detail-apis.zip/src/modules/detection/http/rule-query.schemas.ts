import { z } from "zod";

export const listRulesQuerySchema = z.object({
  status: z.enum(["active", "disabled", "archived"]).optional(),
  type: z.enum(["match", "count", "sequence"]).optional(),
  severity: z.enum(["critical", "high", "medium", "low", "informational"]).optional(),
  search: z.string().trim().min(1).max(200).optional(),
  tag: z.string().trim().min(1).max(200).optional(),
  isBuiltin: z.enum(["true", "false"]).transform((value) => value === "true").optional(),
  page: z.coerce.number().int().min(1).max(1_000_000).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(25),
  sort: z.enum(["name", "severity", "status", "createdAt", "updatedAt"]).default("name"),
  order: z.enum(["asc", "desc"]).default("asc"),
});

export const ruleIdParamsSchema = z.object({
  id: z.string().uuid(),
});
