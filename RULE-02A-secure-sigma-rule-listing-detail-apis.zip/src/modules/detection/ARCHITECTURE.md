# Detection Module Architecture

The detection module compiles and evaluates the supported Sigma-inspired rule subset and exposes authenticated, tenant-scoped rule investigation reads. YAML remains the stored source of truth; compiled match/count representations are runtime artifacts.

## RULE-02A Query Boundary

```mermaid
flowchart TD
    HTTP["GET /api/v1/rules or /:id"]
    AUTH["authenticateRequest() + rules.view"]
    VALIDATE["Zod query/path validation"]
    USECASE["ListRulesUseCase / GetRuleDetailUseCase"]
    CONTRACT["IRuleQueryRepository"]
    REPO["PostgresRuleQueryRepository"]
    PG["PostgreSQL rules + alert aggregates"]

    HTTP --> AUTH --> VALIDATE --> USECASE --> CONTRACT
    REPO --> CONTRACT
    REPO --> PG
```

`createRuleQueryDependencies(postgres)` is the module composition function. `src/main.ts` calls it with the shared PostgreSQL client and passes the resulting use cases through `startServer()` and `createApp()` to `createRuleQueryRouter()`.

## Security and Data Flow

- The router accepts an organization only from `AuthenticatedPrincipal.orgId`; query-string attempts to supply `orgId` are ignored.
- Every repository list, count, detail, and alert-statistics query applies the trusted organization before returning data. A cross-tenant detail lookup is indistinguishable from an absent rule and returns `404`.
- `rules.view` is granted to Admin, Security Engineer, and SOC Analyst. Authentication runs before authorization.
- Zod allowlists all filters and sort fields, bounds pagination, and requires UUID detail identifiers. Sort columns are selected from a fixed server-side mapping.
- List responses deliberately omit YAML, compilation hashes, false-positive guidance, references, and actor identifiers. Detail responses include full YAML and compilation metadata but never `org_id`.
- Alert counts and last-triggered timestamps come from a same-tenant aggregate of `public.alerts`; rules without alerts return zero and `null`.
- `20261022000100_rule_02a_query_indexes.js` adds tenant-first rule listing and alert-statistics indexes plus a GIN tag index.
- Priority is read from a bounded top-level YAML scalar when available, with the stored rule weight supplying a stable compatibility fallback for historical rows. Listing does not invoke compilation or execute rule content.

## Existing Evaluation Boundary

The rule engine loaders retrieve active rules per organization, validate and compile YAML, atomically replace the organization cache, and retain last-known-good rules when a reload candidate fails. Match rules are stateless; count rules use Redis-backed rolling windows and cooldown state. Alert persistence is handled separately from RULE-02A reads.

## Important Components

- `http/rule-query.routes.ts`: authenticated HTTP handlers and error mapping.
- `http/rule-query.schemas.ts`: query/path allowlists and bounds.
- `application/list-rules.use-case.ts`: pagination DTO and list-field minimization.
- `application/get-rule-detail.use-case.ts`: full rule detail DTO.
- `domain/rule-query.contracts.ts`: application-owned repository and response contracts.
- `infrastructure/postgres-rule-query.repository.ts`: tenant-safe rule reads and alert aggregation.
- `composition/rule-query.dependencies.ts`: concrete query dependency assembly.
- `infrastructure/yaml-rule-document.parser.ts`: bounded, single-document YAML parsing shared with compilation.
