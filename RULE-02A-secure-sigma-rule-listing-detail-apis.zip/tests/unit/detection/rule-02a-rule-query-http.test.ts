import assert from "node:assert/strict";
import type { Server } from "node:http";
import type { AddressInfo } from "node:net";
import test from "node:test";

import express, { type Express } from "express";

import type { AppConfig } from "../../../src/config/index.js";
import type { AuthRole, IJwtService, JwtClaims, SessionRecord, UserRecord } from "../../../src/modules/auth/domain/index.js";
import type { GetRuleDetailQuery, ListRulesQuery, RuleDetailView } from "../../../src/modules/detection/domain/rule-query.contracts.js";
import { createRuleQueryRouter } from "../../../src/modules/detection/http/rule-query.routes.js";

const USER_ID = "550e8400-e29b-41d4-a716-446655440001";
const RULE_ID = "00000000-0000-4000-8000-000000000101";

test("RULE-02A endpoints require authentication", async () => {
  const harness = createHarness();
  await withServer(harness.app, async (baseUrl) => {
    assert.equal((await fetch(`${baseUrl}/api/v1/rules`)).status, 401);
    assert.equal((await fetch(`${baseUrl}/api/v1/rules/${RULE_ID}`)).status, 401);
  });
});

for (const role of ["admin", "security_engineer", "soc_analyst"] as const) {
  test(`RULE-02A permits authenticated ${role} and uses the trusted tenant`, async () => {
    const harness = createHarness();
    harness.addToken(`${role}-token`, role, `org-${role}`);
    await withServer(harness.app, async (baseUrl) => {
      const response = await requestJson(
        baseUrl,
        "/api/v1/rules?status=active&type=count&severity=high&search=ssh&tag=attack.t1110&isBuiltin=true&page=2&limit=10&sort=severity&order=desc&orgId=forged",
        `${role}-token`,
      );
      assert.equal(response.status, 200);
    });
    assert.deepEqual(harness.listInputs[0], {
      orgId: `org-${role}`,
      status: "active",
      type: "count",
      severity: "high",
      search: "ssh",
      tag: "attack.t1110",
      isBuiltin: true,
      page: 2,
      limit: 10,
      sort: "severity",
      order: "desc",
    });
  });
}

test("RULE-02A rejects malformed filters and identifiers before use-case execution", async () => {
  const harness = createHarness();
  harness.addToken("reader", "soc_analyst", "org-alpha");
  await withServer(harness.app, async (baseUrl) => {
    for (const query of ["limit=101", "page=0", "isBuiltin=1", "sort=name%3Bdrop", "search="]) {
      const response = await requestJson(baseUrl, `/api/v1/rules?${query}`, "reader");
      assert.equal(response.status, 400, query);
      assert.equal(response.body.error.code, "VALIDATION_ERROR");
    }
    assert.equal((await requestJson(baseUrl, "/api/v1/rules/not-a-uuid", "reader")).status, 400);
  });
  assert.equal(harness.listInputs.length, 0);
  assert.equal(harness.detailInputs.length, 0);
});

test("RULE-02A detail conceals absent or cross-tenant rules with 404", async () => {
  const harness = createHarness();
  harness.addToken("reader", "soc_analyst", "org-alpha");
  await withServer(harness.app, async (baseUrl) => {
    const response = await requestJson(baseUrl, `/api/v1/rules/${RULE_ID}?orgId=forged`, "reader");
    assert.equal(response.status, 404);
    assert.equal(response.body.error.code, "RESOURCE_NOT_FOUND");
  });
  assert.deepEqual(harness.detailInputs, [{ orgId: "org-alpha", ruleId: RULE_ID }]);
});

interface Harness {
  readonly app: Express;
  readonly listInputs: ListRulesQuery[];
  readonly detailInputs: GetRuleDetailQuery[];
  detail: RuleDetailView | null;
  addToken(token: string, role: AuthRole, orgId: string): void;
}

function createHarness(): Harness {
  const jwtService = new FakeJwtService();
  const sessions = new Map<string, SessionRecord>();
  const users = new Map<string, UserRecord>();
  const listInputs: ListRulesQuery[] = [];
  const detailInputs: GetRuleDetailQuery[] = [];
  const harness: Harness = {
    app: express(), listInputs, detailInputs, detail: null,
    addToken(token, role, orgId) {
      const jti = `jwt-${token}`;
      const now = Math.floor(Date.now() / 1_000);
      jwtService.tokens.set(token, { sub: USER_ID, username: "rule-reader", role, jti, iat: now, exp: now + 3600, iss: "ai-siem" });
      sessions.set(jti, session(jti));
      users.set(USER_ID, user(role, orgId));
    },
  };
  harness.app.use("/api/v1/rules", createRuleQueryRouter({
    authentication: {
      jwtService,
      sessionRepository: { async findByJwtId(id) { return sessions.get(id) ?? null; } },
      userRepository: { async findById(id) { return users.get(id) ?? null; } },
      config: TEST_CONFIG,
    },
    listRulesUseCase: {
      async execute(input) {
        listInputs.push(input);
        return { data: [], pagination: { page: input.page, limit: input.limit, total: 0, totalPages: 0, hasNext: false, hasPrev: input.page > 1 } };
      },
    },
    getRuleDetailUseCase: {
      async execute(input) { detailInputs.push(input); return harness.detail; },
    },
  }));
  return harness;
}

class FakeJwtService implements IJwtService {
  public readonly tokens = new Map<string, JwtClaims>();
  public async sign(claims: JwtClaims): Promise<string> { return `signed:${claims.jti}`; }
  public async verify(token: string): Promise<JwtClaims> {
    const claims = this.tokens.get(token);
    if (claims === undefined) throw new Error("Unknown token");
    return claims;
  }
}

function session(jwtId: string): SessionRecord {
  return { id: `session-${jwtId}`, userId: USER_ID, jwtId, ipAddress: null, userAgent: null, expiresAt: new Date(Date.now() + 60_000), createdAt: new Date(), revokedAt: null };
}

function user(role: AuthRole, orgId: string): UserRecord {
  return { id: USER_ID, username: "rule-reader", email: "rule-reader@example.test", passwordHash: "test", role, displayName: "Rule Reader", isActive: true, lastLoginAt: null, failedLoginCount: 0, lockedUntil: null, createdAt: new Date(), updatedAt: new Date(), orgId };
}

async function requestJson(baseUrl: string, path: string, token: string) {
  const response = await fetch(`${baseUrl}${path}`, { headers: { authorization: `Bearer ${token}` } });
  return { status: response.status, body: await response.json() as any };
}

async function withServer(app: Express, callback: (baseUrl: string) => Promise<void>): Promise<void> {
  const server = await new Promise<Server>((resolve) => { const listener = app.listen(0, "127.0.0.1", () => resolve(listener)); });
  try { await callback(`http://127.0.0.1:${(server.address() as AddressInfo).port}`); }
  finally { await new Promise<void>((resolve, reject) => server.close((error) => error === undefined ? resolve() : reject(error))); }
}

const TEST_CONFIG: AppConfig = {
  server: { port: 3000, nodeEnv: "test", apiPrefix: "/api/v1" },
  database: { DATABASE_URL: "postgres://test", MONGODB_URI: "mongodb://test", REDIS_URL: "redis://test", postgres: { poolMin: 0, poolMax: 1, connectionTimeoutMs: 1000, queryTimeoutMs: 1000 }, mongodb: { poolSize: 1, serverSelectionTimeoutMs: 1000 }, redis: { keyPrefix: "test" } },
  jwt: { algorithm: "HS256", secret: "test-jwt-secret-that-is-long-enough-for-rule-query-tests", accessTokenExpiry: "1h", refreshWindow: "5m", maxSessionDuration: "7d", issuer: "ai-siem", cookie: { name: "siem_token", httpOnly: true, secure: true, sameSite: "strict" } },
  auth: { bcryptRounds: 12, lockoutAttempts: 5, lockoutMinutes: 15, rateLimitPerMinute: 10 },
  security: { bcryptSaltRounds: 12, collectorHmacSecret: "collector-secret" },
  collector: { directory: "./collector", trust: { collectorId: "test", keyId: "test", secretBase64Url: "c8Wm1Qx4Ny7Rt2Ks5Vb9Lp3Hd6Fj0Za8Pe1Uy4Mi7Go2Cq5Xs9Dv3Ln6Ak0Jr8Tw" } },
  ai: { engineUrl: "http://localhost:8000", timeoutMs: 5000, batchSize: 100, threshold: 0.65, circuitFailureThreshold: 5, circuitCooldownMs: 60000, circuitSuccessThreshold: 2 },
  frontend: { url: "http://localhost:3001" }, logging: { level: "debug", format: "pretty" },
};
