import type { AuthRole } from "../domain/index.js";

export type Permission =
  | "audit.view"
  | "users.manage"
  | "rules.create"
  | "rules.delete"
  | "rules.edit"
  | "rules.enable"
  | "rules.view"
  | "events.view"
  | "incidents.view"
  | "incidents.assign";

const ROLE_PERMISSIONS: Record<AuthRole, ReadonlySet<Permission>> = {
  admin: new Set([
    "audit.view",
    "users.manage",
    "rules.create",
    "rules.delete",
    "rules.edit",
    "rules.enable",
    "rules.view",
    "events.view",
    "incidents.view",
    "incidents.assign",
  ]),
  security_engineer: new Set([
    "audit.view",
    "rules.create",
    "rules.edit",
    "rules.enable",
    "rules.view",
    "events.view",
    "incidents.view",
    "incidents.assign",
  ]),
  soc_analyst: new Set(["rules.view", "events.view", "incidents.view"]),
};

export function roleHasPermission(
  role: AuthRole,
  permission: Permission,
): boolean {
  return ROLE_PERMISSIONS[role].has(permission);
}
