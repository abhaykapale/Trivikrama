import { z } from "zod";
import { MAX_SIGMA_RULE_SOURCE_BYTES } from "../domain/rule-command.contracts.js";

export const listRulesQuerySchema = z.object({
  status: z.enum(["active", "disabled", "archived"]).optional(),
  type: z.enum(["match", "count", "sequence"]).optional(),
  severity: z.enum(["critical", "high", "medium", "low", "informational"]).optional(),
  search: z.string().trim().min(1).max(200).optional(),
  tag: z.string().trim().min(1).max(200).optional(),
  isBuiltin: z.enum(["true", "false"]).transform((value) => value === "true").optional(),
  page: z.coerce.number().int().min(1).max(1_000_000).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(25),
  sort: z.enum(["name", "severity", "status", "createdAt", "updatedAt"]).default("name"),
  order: z.enum(["asc", "desc"]).default("asc"),
});

export const ruleIdParamsSchema = z.object({
  id: z.string().uuid(),
});

export const createRuleBodySchema = z
  .object({
    yamlContent: z
      .string()
      .min(1)
      .max(MAX_SIGMA_RULE_SOURCE_BYTES)
      .refine(
        (value) => Buffer.byteLength(value, "utf8") <= MAX_SIGMA_RULE_SOURCE_BYTES,
        `yamlContent must not exceed ${MAX_SIGMA_RULE_SOURCE_BYTES} UTF-8 bytes`,
      ),
  })
  .strict();

export const updateRuleBodySchema = createRuleBodySchema;

export const emptyRuleCommandBodySchema = z.object({}).strict();
