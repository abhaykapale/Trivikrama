import type { Server } from "node:http";

import { createApp } from "./app.js";
import config, { type AppConfig } from "./config/index.js";
import logger from "./shared/logger";

import type { CreateAuthRouterDependencies } from "./index.js";
import type { CreateAssetRouterDependencies } from "./index.js";
import type { CreateCollectorMonitoringRouterDependencies } from "./index.js";
import type { CreateDashboardRouterDependencies } from "./index.js";
import type { CreateIncidentQueryRouterDependencies } from "./index.js";
import type { CreateEventQueryRouterDependencies } from "./index.js";
import type { CreateRuleQueryRouterDependencies } from "./index.js";
import type HealthService from "./modules/health/health.service.js";
import type { CreateUsersRouterDependencies } from "./index.js";

export interface StartServerDependencies {
  readonly healthService: HealthService;
  readonly auth?: CreateAuthRouterDependencies;
  readonly assets?: CreateAssetRouterDependencies;
  readonly collectorMonitoring?: CreateCollectorMonitoringRouterDependencies;
  readonly dashboard?: CreateDashboardRouterDependencies;
  readonly incidents?: CreateIncidentQueryRouterDependencies;
  readonly events?: CreateEventQueryRouterDependencies;
  readonly rules?: CreateRuleQueryRouterDependencies;
  readonly users?: CreateUsersRouterDependencies;
  readonly appConfig?: AppConfig;
}

const startServer = ({
  healthService,
  auth,
  assets,
  collectorMonitoring,
  dashboard,
  incidents,
  events,
  rules,
  users,
  appConfig = config,
}: StartServerDependencies): Server => {
  const app = createApp({
    healthService,
    auth,
    assets,
    collectorMonitoring,
    dashboard,
    incidents,
    events,
    rules,
    users,
    appConfig,
  });

  const port = appConfig.server.port;

  const server = app.listen(port, () => {
    logger.info(` Server running on port ${port}`);
  });

  return server;
};

export default startServer;
